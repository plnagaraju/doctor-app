package com.myapp.demo.Model;

import javax.persistence.*;

@Entity
@Table(name = "doctors")
public class Doctor {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@Column(name = "name")
	private String name;

	@Column(name = "speciality")
	private String speciality;

	@Column(name = "salary")
	private Integer salary;

	public Doctor() {
	}

	public Doctor(String name, String speciality) {
		this.name = name;
		this.speciality = speciality;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSpeciality() {
		return speciality;
	}

	public void setSpeciality(String speciality) {
		this.speciality = speciality;
	}

	public Integer getSalary() {
		return salary;
	}

	public void setSalary(Integer salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Doctor{" +
				"id=" + id +
				", name='" + name + '\'' +
				", speciality='" + speciality + '\'' +
				", salary=" + salary +
				'}';
	}
}
